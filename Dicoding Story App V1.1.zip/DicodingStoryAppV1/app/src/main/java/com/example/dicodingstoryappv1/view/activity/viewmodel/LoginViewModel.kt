package com.example.dicodingstoryappv1.view.activity.viewmodel


import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.dicodingstoryappv1.Preference.UserPreference
import com.example.dicodingstoryappv1.data.UserStory
import kotlinx.coroutines.launch

class LoginViewModel (private val pref: UserPreference): ViewModel(){
    fun loginUsers(): LiveData<UserStory> {
        return  pref.getUser().asLiveData()
    }
    fun sessionSave(user: UserStory){
        viewModelScope.launch {
            pref.saveUser(user)
        }
    }

}