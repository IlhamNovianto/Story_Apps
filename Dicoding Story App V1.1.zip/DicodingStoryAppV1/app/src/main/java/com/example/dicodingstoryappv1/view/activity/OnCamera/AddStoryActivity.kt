package com.example.dicodingstoryappv1.view.activity.OnCamera

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.Intent.ACTION_GET_CONTENT
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Toast

import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider

import com.example.dicodingstoryappv1.Utils.reduceFileImage
import com.example.dicodingstoryappv1.Utils.uriToFile
import com.example.dicodingstoryappv1.Utils.createTempFile
import com.example.dicodingstoryappv1.Preference.UserPreference
import com.example.dicodingstoryappv1.R
import com.example.dicodingstoryappv1.Utils.rotateBitmap
import com.example.dicodingstoryappv1.api.ApiConfig
import com.example.dicodingstoryappv1.api.response.AddNewStoryResponse
import com.example.dicodingstoryappv1.view.activity.viewmodel.ViewModelFactory
import com.example.dicodingstoryappv1.databinding.ActivityAddStoryBinding
import com.example.dicodingstoryappv1.view.activity.ListStoryActivity
import com.example.dicodingstoryappv1.view.activity.viewmodel.ListStoryViewModel

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")
class AddStoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddStoryBinding
    private lateinit var currentPhotoPath: String
    private lateinit var addStoryViewModel: ListStoryViewModel

    private var getFile: File? = null

    companion object{
        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)
        private const val REQUEST_CODE_PERMISSIONS = 10
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResult: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResult)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (!allPermissionsGranted()) {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = "Add Story"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        if (!allPermissionsGranted()){
            ActivityCompat.requestPermissions(
                this@AddStoryActivity,
                REQUIRED_PERMISSIONS,
                REQUEST_CODE_PERMISSIONS
            )
        }

        addStoryViewModel = ViewModelProvider(
            this, ViewModelFactory(UserPreference.getInstance(dataStore))
        )[ListStoryViewModel::class.java]

        binding.apply {
            btnGallery.setOnClickListener{
                openGalerry()
            }
            btnCamera.setOnClickListener{
                takePhoto()
            }
            btnUpload.setOnClickListener{
                uploadPhoto()
            }
        }
    }

    private fun takePhoto() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        intent.resolveActivity(packageManager)


        createTempFile(application).also {
            val photoURI: Uri = FileProvider.getUriForFile(
                this@AddStoryActivity,
                "com.example.dicodingstoryappv1",
                it
            )
            currentPhotoPath = it.absolutePath
            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
            launcherIntentCamera.launch(intent)
        }
    }

    private val launcherIntentCamera = registerForActivityResult(ActivityResultContracts.StartActivityForResult()){
        if (it.resultCode == RESULT_OK) {
            val myFile = File(currentPhotoPath)
            getFile = myFile

            val result =BitmapFactory.decodeFile(myFile.path)

            binding.imgAddPreview.setImageBitmap(rotateBitmap(result, true))
        }
    }

    private fun uploadPhoto() {
        val desc = binding.etDescriptionStory.text.toString()
        when {
            desc.isEmpty() -> {
                binding.etDescriptionStory.error = resources.getString(R.string.null_desc_msg)
            } else -> {
                showLoading(true)
                if (getFile != null) {
                    val file = reduceFileImage(getFile as File)
                    val description = binding.etDescriptionStory.text.toString().toRequestBody("text/plain".toMediaType())
                    val requestImg = file.asRequestBody("image/jpeg".toMediaTypeOrNull())
                    val imgMultipart: MultipartBody.Part =  MultipartBody.Part.createFormData(
                        "photo",
                        file.name,
                        requestImg
                    )

                    addStoryViewModel.getUser().observe(this){ add ->
                        if (add != null) {
                            ApiConfig.getApiService().postStory("Bearer " + add.token, imgMultipart, description)
                                .enqueue(object : Callback<AddNewStoryResponse>{
                                    override fun onResponse(
                                        call: Call<AddNewStoryResponse>,
                                        response: Response<AddNewStoryResponse>,
                                    ) {
                                        showLoading(false)
                                        if (response.isSuccessful){
                                            Toast.makeText(
                                                this@AddStoryActivity,
                                                getString(R.string.upload_sucsessful_msg),
                                                Toast.LENGTH_SHORT).show()
                                            moveToUserStory()
                                            finish()
                                        } else {
                                            Toast.makeText(
                                                this@AddStoryActivity,
                                                getString(R.string.upload_failed_msg),
                                                Toast.LENGTH_SHORT).show()
                                        }
                                    }

                                    override fun onFailure(
                                        call: Call<AddNewStoryResponse>, t: Throwable,
                                    ) {
                                        Toast.makeText(
                                            this@AddStoryActivity,
                                            getString(R.string.upload_failed_msg),
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }

                                })
                        }
                    }
                }
            }
        }
    }

    private fun moveToUserStory() {
        Intent(this@AddStoryActivity, ListStoryActivity::class.java)
        finish()
    }

    private fun openGalerry() {
        val intent = Intent()
        intent.action = ACTION_GET_CONTENT
        intent.type = "image/*"
        val chooser = Intent.createChooser(intent, getString(R.string.choosepicture))
        launcherIntentGallery.launch(chooser)
    }
   private val launcherIntentGallery = registerForActivityResult(ActivityResultContracts.StartActivityForResult()){
       if (it.resultCode == RESULT_OK) {
           val selectedImg: Uri = it.data?.data as Uri
           val myPicture = uriToFile(selectedImg, this@AddStoryActivity)
           getFile = myPicture
           binding.imgAddPreview.setImageURI(selectedImg)
       }
   }

    private fun showLoading(isLoading: Boolean){
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
}