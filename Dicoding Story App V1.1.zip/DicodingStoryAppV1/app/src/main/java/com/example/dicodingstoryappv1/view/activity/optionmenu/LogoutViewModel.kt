package com.example.dicodingstoryappv1.view.activity.optionmenu

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.dicodingstoryappv1.Preference.UserPreference
import kotlinx.coroutines.launch

class LogoutViewModel(private val pref: UserPreference): ViewModel() {
    fun userLogout() {
        viewModelScope.launch {
            pref.userLogout()
        }
    }
}