package com.example.dicodingstoryappv1.view.activity.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.dicodingstoryappv1.Preference.UserPreference
import com.example.dicodingstoryappv1.view.activity.optionmenu.LogoutViewModel

class ViewModelFactory(private val pref: UserPreference)
    : ViewModelProvider.NewInstanceFactory() {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ListStoryViewModel::class.java)) {
            return ListStoryViewModel(pref) as T
        }

        if (modelClass.isAssignableFrom(LoginViewModel::class.java)) {
            return LoginViewModel(pref) as T
        }

        if (modelClass.isAssignableFrom(LogoutViewModel::class.java)) {
            return LogoutViewModel(pref) as T
        }

        throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
    }
}