package com.example.dicodingstoryappv1.view.activity

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.dicodingstoryappv1.Adapter.StoryAdapter
import com.example.dicodingstoryappv1.Preference.UserPreference
import com.example.dicodingstoryappv1.R
import com.example.dicodingstoryappv1.api.ApiConfig
import com.example.dicodingstoryappv1.api.response.GetAllStoryResponse
import com.example.dicodingstoryappv1.api.response.ListStoryItem
import com.example.dicodingstoryappv1.data.CardStory
import com.example.dicodingstoryappv1.databinding.ActivityListStoryBinding
import com.example.dicodingstoryappv1.gateapps.MainActivity
import com.example.dicodingstoryappv1.view.activity.OnCamera.AddStoryActivity
import com.example.dicodingstoryappv1.view.activity.viewmodel.ViewModelFactory
import com.example.dicodingstoryappv1.view.activity.optionmenu.LogoutViewModel
import com.example.dicodingstoryappv1.view.activity.viewmodel.ListStoryViewModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")
class ListStoryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityListStoryBinding
    private lateinit var logoutViewModel: LogoutViewModel
    private lateinit var listStoryViewModel: ListStoryViewModel
    private lateinit var adapter: StoryAdapter

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            binding = ActivityListStoryBinding.inflate(layoutInflater)
            setContentView(binding.root)

            supportActionBar?.title = getString(R.string.story_user)

            setupLogoutViewModel()
            setupListStoryViewModel()
            setupGetStory()

            binding.apply {
                rvUser.layoutManager = LinearLayoutManager(this@ListStoryActivity)
                rvUser.setHasFixedSize(true)
            }

            binding.fabAddStory.setOnClickListener{
                startActivity(Intent(this, AddStoryActivity::class.java))
            }
        }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.option_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId){
            R.id.logout -> {
                logoutViewModel.userLogout()
                Intent(this@ListStoryActivity, MainActivity::class.java).also {
                    startActivity(it)
                    finish()
                }
                true
            }
            R.id.settingLanguage -> {
                startActivity(Intent(Settings.ACTION_LOCALE_SETTINGS))
                true
            }
            else -> true
        }
    }

    private fun setupLogoutViewModel() {
        logoutViewModel = ViewModelProvider(this,
            ViewModelFactory(UserPreference.getInstance(dataStore))) [LogoutViewModel::class.java]
    }

    private fun setupListStoryViewModel() {
        listStoryViewModel = ViewModelProvider(this,
            ViewModelFactory(UserPreference.getInstance(dataStore))) [ListStoryViewModel::class.java]
    }

    private fun setupGetStory() {
        showLoading(true)

        listStoryViewModel.getUser().observe(this) {stories ->
            if(stories != null) {
                ApiConfig.getApiService().getAllStory("Bearer " + stories.token)
                    .enqueue(object: Callback<GetAllStoryResponse> {
                        override fun onResponse(
                            call: Call<GetAllStoryResponse>,
                            response: Response<GetAllStoryResponse>
                        ) {
                            showLoading(false)
                            if(response.isSuccessful) {
                                getStories(response.body()?.listStory!!)
                                Toast.makeText(
                                    this@ListStoryActivity,
                                    resources.getString(R.string.LoadSuccesfull),
                                    Toast.LENGTH_SHORT).show()
                            }
                        }
                        override fun onFailure(call: Call<GetAllStoryResponse>, t: Throwable) {
                            showLoading(false)
                            Toast.makeText(this@ListStoryActivity,
                            "Load Field",
                            Toast.LENGTH_SHORT).show()
                        }
                    })
            }
        }
    }

    private fun getStories (list: List<ListStoryItem>){
        val listStrories = ArrayList<CardStory>()
        for (item in list) {
            val story = CardStory (
                item.photoUrl,
                item.name,
                item.description,
            )
            listStrories.add(story)
        }
        adapter = StoryAdapter(listStrories)
        binding.rvUser.adapter = adapter
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progresBar.visibility = if (isLoading) View.VISIBLE else View.GONE

    }



    }

