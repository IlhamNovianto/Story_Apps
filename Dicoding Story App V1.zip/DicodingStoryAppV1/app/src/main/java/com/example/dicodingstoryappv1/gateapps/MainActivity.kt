package com.example.dicodingstoryappv1.gateapps

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import com.example.dicodingstoryappv1.Preference.UserPreference
import com.example.dicodingstoryappv1.api.ApiConfig
import com.example.dicodingstoryappv1.api.response.LoginResponse
import com.example.dicodingstoryappv1.data.UserStory
import com.example.dicodingstoryappv1.databinding.ActivityMainBinding
import com.example.dicodingstoryappv1.view.activity.ListStoryActivity
import com.example.dicodingstoryappv1.view.activity.viewmodel.LoginViewModel
import com.example.dicodingstoryappv1.view.activity.viewmodel.ViewModelFactory
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")


private lateinit var binding: ActivityMainBinding
private lateinit var loginViewModel: LoginViewModel

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setAnimation()
        setupLogin()
        setupRegister()

        binding.apply {
            btnLogin.setOnClickListener{
                setupAction()
            }
        }
    }

    private fun setAnimation() {
        val title = ObjectAnimator.ofFloat(binding.storyApp, View.ALPHA, 1f).setDuration(500)
        val subtitle = ObjectAnimator.ofFloat(binding.subtitle, View.ALPHA, 1f).setDuration(500)
        val btnLogin = ObjectAnimator.ofFloat(binding.btnLogin, View.ALPHA, 1f).setDuration(500)
        val btnRegister1 = ObjectAnimator.ofFloat(binding.btnRegister1, View.ALPHA, 1f).setDuration(500)

        AnimatorSet().apply {
            playSequentially(title, subtitle, btnLogin, btnRegister1)
            start()
        }
    }
    private fun setupRegister() {
        binding.btnRegister1.setOnClickListener{
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }

    private fun setupAction() {
        val loginEmail = binding.etLoginEmail.text.toString()
        val loginPass = binding.etLoginPassword.text.toString()

        if (binding.etLoginEmail.length() == 0 && binding.etLoginPassword.length() == 0) {
            binding.etLoginEmail.error = "Email must be filled"
            binding.etLoginPassword.error = "Password must Be Filled"
        }
        else if (binding.etLoginEmail.length() != 0 && binding.etLoginPassword.length() != 0){
            showLoading(true)
            ApiConfig.getApiService().login(loginEmail, loginPass)
                .enqueue(object : Callback<LoginResponse>{
                    override fun onResponse(
                        call: Call<LoginResponse>,
                        response: Response<LoginResponse>,
                    ) {
                        showLoading(false)
                        if (response.isSuccessful) {
                            response.body()?. loginResult?.apply {
                                saveSession(token)
                            }
                            Toast.makeText(
                                this@MainActivity,
                                "Login Sucsessful",
                                Toast.LENGTH_SHORT). show()
                        }else{
                            Toast.makeText(this@MainActivity, "Login Failed", Toast.LENGTH_SHORT).show()
                        }
                    }

                    override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                        Toast.makeText(this@MainActivity, "Login Failed", Toast.LENGTH_SHORT).show()
                    }

                })
        }
    }

    private fun saveSession(token: String) {
        loginViewModel.sessionSave(UserStory(token, true))
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE

    }

    private fun setupLogin() {
        loginViewModel = ViewModelProvider(this,
            ViewModelFactory(UserPreference.getInstance(dataStore)))[LoginViewModel::class.java]

        loginViewModel.loginUsers().observe(this) { users ->
            if (users.isLogin){
                startActivity(Intent(this, ListStoryActivity::class.java))
                finish()
            }
        }
    }
}



