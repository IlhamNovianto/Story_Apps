package com.example.dicodingstoryappv1.view.activity.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.example.dicodingstoryappv1.Preference.UserPreference
import com.example.dicodingstoryappv1.data.UserStory

class ListStoryViewModel(private val pref: UserPreference): ViewModel() {
    fun getUser() : LiveData<UserStory> {
        return  pref.getUser().asLiveData()
    }
}