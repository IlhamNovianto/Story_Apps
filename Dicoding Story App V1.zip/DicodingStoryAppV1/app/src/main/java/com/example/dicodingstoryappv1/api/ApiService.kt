package com.example.dicodingstoryappv1.api

import com.example.dicodingstoryappv1.api.response.AddNewStoryResponse
import com.example.dicodingstoryappv1.api.response.GetAllStoryResponse
import com.example.dicodingstoryappv1.api.response.LoginResponse
import com.example.dicodingstoryappv1.api.response.RegisterResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.http.*

interface ApiService {
    @FormUrlEncoded
    @POST("register")
    fun register(
        @Field("name") name : String,
        @Field("email") email : String,
        @Field("password") password : String
    ): Call<RegisterResponse>

    @FormUrlEncoded
    @POST("login")
    fun login(
        @Field("email") email: String,
        @Field("password") password: String
    ): Call<LoginResponse>

    @GET("stories")
    fun getAllStory(
        @Header("Authorization") token : String
    ): Call<GetAllStoryResponse>

    @Multipart
    @POST("stories")
    fun postStory(
        @Header("Authorization") token: String,
        @Part file : MultipartBody.Part,
        @Part("description") description : RequestBody
    ): Call<AddNewStoryResponse>
}