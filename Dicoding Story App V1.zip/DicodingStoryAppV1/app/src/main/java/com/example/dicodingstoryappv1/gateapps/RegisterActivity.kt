package com.example.dicodingstoryappv1.gateapps

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.example.dicodingstoryappv1.R
import com.example.dicodingstoryappv1.api.ApiConfig
import com.example.dicodingstoryappv1.api.response.RegisterResponse
import com.example.dicodingstoryappv1.databinding.ActivityRegisterBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding : ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = "register"

        setAnimation()

        binding.apply {
            btnRegister.setOnClickListener{
                registerOnClick()
            }
        }
    }

    private fun setAnimation() {
        val regisTitle = ObjectAnimator.ofFloat(binding.regisTitle, View.ALPHA, 1f).setDuration(500)
        val btnRegisName = ObjectAnimator.ofFloat(binding.tilName, View.ALPHA, 1f).setDuration(500)
        val btnRegisEmail = ObjectAnimator.ofFloat(binding.tilEmail, View.ALPHA, 1f).setDuration(500)
        val btnRegisPassword = ObjectAnimator.ofFloat(binding.tilPassword, View.ALPHA, 1f).setDuration(500)
        val btnRegis2 = ObjectAnimator.ofFloat(binding.btnRegister, View.ALPHA, 1f).setDuration(500)

        AnimatorSet().apply {
            playSequentially(regisTitle, btnRegisName, btnRegisEmail, btnRegisPassword, btnRegis2)
            start()
        }
    }

    private fun registerOnClick() {
        val regisName = binding.etRegisName.text.toString()
        val regisEmail = binding.etRegisEmail.text.toString()
        val regisPass = binding.etRegisPassword.text.toString()

        if (binding.etRegisName.length() == 0 && binding.etRegisName.length() == 0 && binding.etRegisPassword.length() == 0
        ) {
            binding.etRegisName.error = resources.getString(R.string.name_empty_msg)
            binding.etRegisEmail.error = resources.getString(R.string.wrong_format_email)
            binding.etRegisPassword.error = resources.getString(R.string.password_invalid_msg)
        }
        else if (binding.etRegisName.length() != 0 && binding.etRegisName.length() != 0 && binding.etRegisPassword.length() != 0 ) {
            showLoading(true)

            ApiConfig.getApiService().register(regisName, regisEmail, regisPass).
            enqueue(object : Callback<RegisterResponse>{
                override fun onResponse(call: Call<RegisterResponse>,
                response: Response<RegisterResponse>
                ){
                    showLoading(false)
                    if (response.isSuccessful){
                        startActivity(Intent(this@RegisterActivity,
                        MainActivity::class.java))
                        finish()
                        Toast.makeText(this@RegisterActivity,
                        getString(R.string.registerBerhasil), Toast.LENGTH_SHORT).show()
                        showLoading(true)
                    } else {
                        Toast.makeText(this@RegisterActivity,
                        getString(R.string.registergagal), Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onFailure(call: Call<RegisterResponse>, t: Throwable) {
                    Toast.makeText(this@RegisterActivity,  getString(R.string.registerBerhasil), Toast.LENGTH_SHORT).show()
                }
            })

        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
}