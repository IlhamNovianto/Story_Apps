package com.example.dicodingstoryappv1.Adapter

import android.app.Activity
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.app.ActivityOptionsCompat
import androidx.core.util.Pair
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.example.dicodingstoryappv1.R
import com.example.dicodingstoryappv1.data.CardStory
import com.example.dicodingstoryappv1.databinding.CardUserBinding
import com.example.dicodingstoryappv1.view.activity.DetailActivity

class StoryAdapter(private val story : ArrayList<CardStory>): RecyclerView.Adapter<StoryAdapter.ViewHolder>() {
    //cara Lain dari Object constructur di atas adalah :private val story = ArrayList<CardStory>()

    inner class ViewHolder (binding: CardUserBinding): RecyclerView.ViewHolder(binding.root) {
    val tvName: TextView = itemView.findViewById(R.id.tv_name_incard)
    val tvDesc: TextView = itemView.findViewById(R.id.tv_desc_incard)
    val imgUrl: ImageView = itemView.findViewById(R.id.iv_avatar_incard)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = CardUserBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        Glide.with(holder.itemView.context)
            .load(story[position].photoUrl)
            .into(holder.imgUrl)
        holder.tvName.text = story[position].name
        holder.tvDesc.text = story[position].description


        //mengklik salah satu gambar pada RecyclerView
        holder.itemView.setOnClickListener {
            val intent = Intent(holder.itemView.context, DetailActivity::class.java)
            intent.putExtra(DetailActivity.DETAIL, story[position])

            val optionsCompat: ActivityOptionsCompat =
                ActivityOptionsCompat.makeSceneTransitionAnimation(
                holder.itemView.context as Activity,

                Pair(holder.tvName, "nameHolder"),
                Pair(holder.tvDesc, "descHolder")
            )
            holder.itemView.context.startActivity(intent, optionsCompat.toBundle())
        }
    }

    override fun getItemCount(): Int = story.size

}